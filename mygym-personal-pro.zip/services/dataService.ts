
import { Exercise, PersonalRecord, DailyDiet, User } from '../types';
import { INITIAL_EXERCISES } from '../constants';
import { authService } from './authService';

const getStoreKey = (prefix: string) => {
  const user = authService.getCurrentUser();
  return user ? `${prefix}_${user.id}` : prefix;
};

const STORAGE_KEYS = {
  EXERCISES: 'mygym_exercises',
  PRS: 'mygym_prs',
  DIET: 'mygym_diet'
};

export const dataService = {
  getExercises: (): Exercise[] => {
    const key = getStoreKey(STORAGE_KEYS.EXERCISES);
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : INITIAL_EXERCISES;
  },
  saveExercises: (exercises: Exercise[]) => {
    const key = getStoreKey(STORAGE_KEYS.EXERCISES);
    localStorage.setItem(key, JSON.stringify(exercises));
  },
  updateExercise: (id: string, updates: Partial<Exercise>) => {
    const exercises = dataService.getExercises();
    const updated = exercises.map(ex => ex.id === id ? { ...ex, ...updates } : ex);
    dataService.saveExercises(updated);
  },
  getPRs: (): PersonalRecord[] => {
    const key = getStoreKey(STORAGE_KEYS.PRS);
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  },
  savePR: (pr: PersonalRecord) => {
    const prs = dataService.getPRs();
    const updated = [pr, ...prs];
    const key = getStoreKey(STORAGE_KEYS.PRS);
    localStorage.setItem(key, JSON.stringify(updated));
  },
  getDiet: (): DailyDiet => {
    const key = getStoreKey(STORAGE_KEYS.DIET);
    const data = localStorage.getItem(key);
    const user = authService.getCurrentUser();
    
    if (data) return JSON.parse(data);
    
    return {
      userId: user?.id || '',
      breakfast: [],
      lunch: [],
      dinner: [],
      snacks: []
    };
  },
  saveDiet: (diet: DailyDiet) => {
    const key = getStoreKey(STORAGE_KEYS.DIET);
    localStorage.setItem(key, JSON.stringify(diet));
  }
};
