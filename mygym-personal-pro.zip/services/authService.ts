
import { User } from '../types';

const USER_KEY = 'mygym_auth_user';

export const authService = {
  // Added missing login method to handle manual login
  login: async (email: string, name: string): Promise<User> => {
    const user: User = {
      id: 'user_' + Math.random().toString(36).substr(2, 9),
      email: email,
      name: name
    };
    
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    return user;
  },

  // Simula o Firebase Anonymous Login
  loginAnonymously: async (): Promise<User> => {
    const existingUser = authService.getCurrentUser();
    if (existingUser) return existingUser;

    const anonymousId = 'guest_' + Math.random().toString(36).substr(2, 9);
    const user: User = {
      id: anonymousId,
      email: 'anonimo@mygym.com',
      name: 'Visitante'
    };
    
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    return user;
  },
  
  logout: () => {
    localStorage.removeItem(USER_KEY);
  },
  
  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
  }
};